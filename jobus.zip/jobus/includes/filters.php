<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit(); // Exit if accessed directly.
}

//Add Image Size
add_image_size('jobus_280x268', 280, 268, true ); //Candidate Profile 01/02