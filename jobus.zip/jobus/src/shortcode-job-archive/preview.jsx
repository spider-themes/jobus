export const Preview = () => (
    <h3>Here is a set of <strong>job archive layout</strong> shortcodes for your block widgets. These shortcodes are
        designed specifically to display job archive layouts</h3>
);
