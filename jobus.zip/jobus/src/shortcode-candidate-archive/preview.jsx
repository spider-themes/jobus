export const Preview = () => (
    <h3>Here is a set of <strong>candidate archive layout</strong> shortcodes for your block widgets. These shortcodes are
        designed specifically to display candidate archive layouts</h3>
);
