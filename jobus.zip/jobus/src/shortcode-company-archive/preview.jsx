export const Preview = () => (
    <h3>Here is a set of <strong>company archive layout</strong> shortcodes for your block widgets. These shortcodes are
        designed specifically to display company archive layouts</h3>
);
