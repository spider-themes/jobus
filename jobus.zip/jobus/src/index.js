/**
 * Includes all blocks root files
 */
import './video-popup/index';
import './group-testimonials/index';
import './testimonials-item/index';
import './shortcode-job-archive/index';
import './shortcode-company-archive/index';
import './shortcode-candidate-archive/index';
import './register-form/index';